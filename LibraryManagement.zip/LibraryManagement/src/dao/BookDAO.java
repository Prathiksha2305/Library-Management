package dao;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import db.DBConnection;
	import model.Book;

	public class BookDAO {


	    public void addBook(Book book) {

	        try {

	            Connection con = DBConnection.getConnection();

	            String sql = "INSERT INTO books VALUES(?,?,?)";

	            PreparedStatement ps = con.prepareStatement(sql);

	            ps.setInt(1, book.getId());
	            ps.setString(2, book.getTitle());
	            ps.setString(3, book.getAuthor());

	            ps.executeUpdate();

	            System.out.println("Book Added Successfully");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public void viewBooks() {

	        try {

	            Connection con = DBConnection.getConnection();

	            String sql = "SELECT * FROM books";

	            PreparedStatement ps = con.prepareStatement(sql);

	            ResultSet rs = ps.executeQuery();

	            while (rs.next()) {

	                System.out.println(
	                        rs.getInt("id") + " "
	                        + rs.getString("title") + " "
	                        + rs.getString("author"));
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

}
